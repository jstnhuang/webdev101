function getName() {
  return $("#name").text();
}

// Comment this.
// info is the name of the id with the basic info.
function getBasicInfo(id) {
  var rawString = $("#" + id).text();
  var colonIndex = rawString.indexOf(":");
  return rawString.substring(colonIndex+2);
}

/**
 * Creates a 1st person blurb about a person given some facts about them.
 * 
 * Args:
 *  name: The person's name.
 *  major: The person's major.
 *  college: Just the name of the college, e.g., "Warren"
 *  year: E.g., "1st", "2nd", "3rd", ...
 *  funFact: A full sentence with a fun fact.
 *
 * Returns:
 *  A string with a sentence about the person.
 */
function makeBlurb(name, major, college, year, funFact) {
  return "Hi, my name is " + name + ". I'm a " + year + " year "
    + major + " major in " + college + " College. " + funFact;
}

function getBlurb() {
  return makeBlurb(
      getName(),
      getBasicInfo("major"),
      getBasicInfo("college"),
      getBasicInfo("year"),
      getBasicInfo("funFact")
    );
}