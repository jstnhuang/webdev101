// Gets the inputs from the input area and puts them into an array.
function getInputs() {
    var formInputs = $('.inputArea :input');
    var inputs = new Array();
    formInputs.each(function() {
        var name = $(this).attr('name');
        var value = $(this).val();
        inputs[name] = value;
    });
    
    return inputs
}

// Returns the text that should be at the top of the card (e.g.,
// "Happy birthday, George!"
function makeCardTitle(occasion, name) {
    var title = '';
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    title += '!';
    return title;
}

// Replaces newline characters with line breaks to put into HTML code.
function makeCardMessage(message) {
    return message.replace(/\n/g, '<br />');
}

function changeBackground(background) {
    var image = '';
    
    
    
    
    
    
    
    
    
    
    $('#card').css('background-image', 'url(images/' + image + ')');
}

// This function generates the HTML code for the card, using the inputs given in
// the input area.
function generateCard() {
    var inputs = getInputs();
    
    var cardTitle = makeCardTitle(inputs['occasion'], inputs['name']);
    
    
    
    var cardMessage = makeCardMessage(inputs['message']);
    
    
    
    if (cardMessage != '') {
    
    }
    
    changeBackground(inputs['background']);
    $('#card').fadeIn();
}

// Initialize the card creator.
function init() {
    // When the user clicks on "Make card", call the code that generates the
    // card.
    $('#card').hide();
    $('.inputArea input[name=submit]').click(generateCard);
}