/**
 * Example: Variables ----------------------------------------------------------
 */
 
var where = "CSE Basement",
    room = 270,
    workshop = 'Cooking with George Bluefin',
    optimalTemperature = 350.00,
    isGeorgeATuna = true,
     
    // And some more examples. We'll declare these but won't give them values.
     
    $dollars,
    o_0,
    one23,
    __;
    

var aFewTypes    = ['String', 'Number', 'Boolean', 'Object'],
    typeExamples = ['123',     123,      false,    aFewTypes],
    emptyArray   = [];
    
var typeOf123   = aFewTypes[0], // 'String', the 1st (zero-th) element of aFewTypes
    typeOfFalse = aFewTypes[2]; // false, the 3rd element of aFewTypes
     
typeExamples[2] = true;         // Sets the third element to true   
typeExamples[0] = 'abc';        // Now typeExamples is ['abc', 123, true, aFewTypes]
emptyArray[0] = 'Not empty!';   // Adds an element to emptyArray
emptyArray[1] = 'Full!';        // emptyArray is ['Not empty!', 'Full!']


/**
 * Example: Objects ------------------------------------------------------------
 */

var ingredients = ['Salt', 'Pepper'],
    howMany = ingredients.length;
     
//alert(ingredients.length);                   // Shows 2
ingredients[ingredients.length] = 'Tuna';   // Clever way to add to an array.
//alert(ingredients.length);                   // Shows 3
//alert(howMany);                              // Shows 2
 
//alert(document.location)                     // Shows the current URL


/**
 * Example: Operators ----------------------------------------------------------
 */

var a  = 123,
    t  = 2,
    f  = 4,
    s  = 6,
    z  = 0,
     
    sum,
    product,
    difference,
    quotient,
    equal,
    uhoh;
     
sum        =    t + f + z;     // 6
product    =    f * z;         // 0
difference =    t - f;         // -2
quotient   =    f / t;         // 2
uhoh       =    a + f;         // 123 + "4" = "1234"
 
/**
 * Parentheses are used to change the order of operations. They aren't necessary
 * here, but they make it more obvious what's happening.
 */
equal      = (t + f) == 6;              // true
 
/**
 * It's ok to change the value of a variable.
 *
 * (2 !== 4) is true,
 * (4 > 2) is true, and
 * (true === true) is true
 */
equal      = (t !== f) === (f > t);     // true


/**
 * Example: Conditionals -------------------------------------------------------
 */
 
var ingredients = [];
 
if (george.isTasty === true) {
    // Make sure George is invited before putting him on the menu
    if (george.invited === false) {
        george.invited = true;
        sendInvitation(george);     // A function call, covered in the next section
    }
     
    ingredients[ingredients.length] = george;
}
else {
    george.invited = false;
}


/**
 * Example: Functions ----------------------------------------------------------
 */

function divide(a, b) {
    var result;
     
    if (b !== 0) {
        result = a / b;
    }
    else {
        result = 0;
    }
     
    return result;
}
 
var number    = divide(12, 3) + 1,  // 4 + 1
    blackhole = divide(12, 0);      // 0
    
var tens = 10, hundreds = 100, thousands = 1000;

    
/**
 * As mentioned before, functions can contain other functions.
 */
function outer() {
    var tens = 20, hundreds = 200;
 
    function inner() {
        var tens = 30;
         
        // Inner: 30, 20, 1000
        alert('Inner: ' + tens + ', ' + hundreds + ', ' + thousands);
    }
     
    // Outer: 20, 200, 1000
    alert('Outer: ' + tens + ', ' + hundreds + ', ' + thousands);
    inner();
}
 
// Outside both: 10, 100, 1000
alert('Outside both: ' + tens + ', ' + hundreds + ', ' + thousands);
outer();


/**
 * str.replace(replace_this, with_this) returns a copy of str with
 * every instance of replace_this replaced by with_this
 *
 * Passing the empty string "" as the second argument deletes
 * every occurrence of the first parameter.
 */
var title    = "Cooking with George Bluefin",
    actually = workshop.replace("with", "");
     
alert(actually);     // Shows "Cooking George Bluefin"
alert(title);        // Shows "Cooking with George Bluefin"



/** 
 * Example: Loops --------------------------------------------------------------
 */

var guests  = ['George', 'George', 'George', 'Tuna Fan', 'Justin', 'Bulat'],
    loop    = 0,
    georges = 0;
 
while (loop < guests.length) {
    if (guests[loop] === 'George') {
        georges++;      // Shorthand for: georges = georges + 1
    }
     
    loop++;
}