<?php
$html = <<<EOT
<!doctype html>
  <head><title>PHP and MySQL test</title></head>
  <body>
    <h1>PHP and MySQL test</h1>
    <p>
EOT;

$dbInfo = parse_ini_file("db.ini");
$db = @mysql_connect($dbInfo["DB_HOST"], $dbInfo["DB_USER"], $dbInfo["DB_PASSWORD"]);
if(@mysql_select_db($dbInfo["DB_NAME"], $db)) {
  $html .= "Your DB looks fine :)";
} else {
  $html .= "Your DB isn't set up properly yet.";
}

$html .= <<<EOT
    </p>
  </body>
</html>
EOT;

echo $html;
?>