<?php

$dbInfo = parse_ini_file("db.ini");
// TODO: connect to the database.

// If action variable is set to "beep", insert a new beep into the DB.
if (isset($_POST["action"]) && $_POST["action"] === "beep") {
  $name = trim($_POST["name"]);
  $beep = trim($_POST["beep"]);
  // TODO: insert the beep into the database.
}

// Otherwise, assume that the action is a request for existing beeps.
else {
  $time = time();
  while((time() - $time) < 1) {
    // TODO: get the last 100 beeps from the database.

    $rows = array();
    if (mysql_num_rows($result) > 0) {
      while ($row = mysql_fetch_array($result, MYSQL_ASSOC)) {
        // TODO: send back row information, including:
        //  beep_id (already handled)
        //  name (HTML escaped)
        //  beep (HTML escaped)
        //  timeString (formatted as Sunday, Jan 15 2012 at 4:04am)
        $row["name"] = htmlspecialchars($row["name"]);
        $row["beep"] = htmlspecialchars($row["beep"]);
        $row["timeString"] = date('l, M j Y \a\t g:ia', strtotime($row["timestamp"]));
        $rows[] = $row;
      }
      echo json_encode($rows);
      break;
    }

    usleep(800);
  }
}

?>